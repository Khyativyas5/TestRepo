package com.siemens.Demogradle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemogradleApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemogradleApplication.class, args);
	}
}
